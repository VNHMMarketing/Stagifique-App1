import { NavigationContainer } from "@react-navigation/native"
import { createStackNavigator } from "@react-navigation/stack"
import HomePage from "./src/screens/HomePage"
import CategoryPage from "./src/screens/CategoryPage"
import AdminLoginScreen from "./src/screens/AdminLoginScreen"
import AdminPanel from "./src/screens/AdminPanel"
import ItemDetailPage from "./src/screens/ItemDetailPage"
import ContactPage from "./src/screens/ContactPage"

const Stack = createStackNavigator()

export default function App() {
  return (
    <NavigationContainer>
      <Stack.Navigator screenOptions={{ headerShown: false }}>
        <Stack.Screen name="Home" component={HomePage} />
        <Stack.Screen name="Category" component={CategoryPage} />
        <Stack.Screen name="AdminLogin" component={AdminLoginScreen} />
        <Stack.Screen name="AdminPanel" component={AdminPanel} />
        <Stack.Screen name="ItemDetail" component={ItemDetailPage} />
        <Stack.Screen name="Contact" component={ContactPage} />
      </Stack.Navigator>
    </NavigationContainer>
  )
}

