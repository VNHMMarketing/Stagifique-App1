import { View, Text, StyleSheet, Image, TouchableOpacity, ScrollView, Linking } from "react-native"
import { useNavigation } from "@react-navigation/native"
import { Ionicons } from "@expo/vector-icons"

const collections = {
  "Living Room": [
    {
      id: "1",
      name: "Modern Minimalist Sofa",
      image: "/placeholder.svg?height=200&width=300",
      brand: "Stagifique",
      price: 1299.99,
      description: "A sleek and comfortable sofa perfect for modern living spaces.",
      material: "Leather and steel",
      dimensions: '80" W x 36" D x 30" H',
      color: "Charcoal Gray",
    },
    {
      id: "2",
      name: "Rustic Charm Coffee Table",
      image: "/placeholder.svg?height=200&width=300",
      brand: "Stagifique",
      price: 499.99,
      description: "A beautiful rustic coffee table that adds warmth to any living room.",
      material: "Reclaimed wood and iron",
      dimensions: '48" W x 24" D x 18" H',
      color: "Natural wood with black accents",
    },
  ],
  Bedroom: [
    {
      id: "3",
      name: "Cozy Retreat Queen Bed",
      image: "/placeholder.svg?height=200&width=300",
      brand: "Stagifique",
      price: 899.99,
      description: "A comfortable and stylish queen-sized bed for your perfect retreat.",
      material: "Solid oak and linen",
      dimensions: '60" W x 80" L x 45" H',
      color: "Warm Oak with Beige Upholstery",
    },
    {
      id: "4",
      name: "Luxe Glamour Vanity",
      image: "/placeholder.svg?height=200&width=300",
      brand: "Stagifique",
      price: 749.99,
      description: "An elegant vanity that adds a touch of glamour to your bedroom.",
      material: "Mirrored glass and gold-plated steel",
      dimensions: '42" W x 18" D x 30" H',
      color: "Mirror finish with gold accents",
    },
  ],
}

const CategoryPage = ({ route }) => {
  const { category } = route.params
  const navigation = useNavigation()

  const sendEmail = () => {
    Linking.openURL("mailto:info@stagifique.com")
  }

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <TouchableOpacity onPress={() => navigation.goBack()}>
          <Ionicons name="arrow-back" size={30} color="black" />
        </TouchableOpacity>
        <Image source={{ uri: "/placeholder.svg?height=40&width=120" }} style={styles.logo} />
        <View style={{ width: 30 }} />
      </View>

      <ScrollView style={styles.content}>
        <Text style={styles.categoryTitle}>{category}</Text>
        {collections[category].map((item) => (
          <TouchableOpacity
            key={item.id}
            style={styles.itemContainer}
            onPress={() => navigation.navigate("ItemDetail", { item })}
          >
            <Image source={{ uri: item.image }} style={styles.itemImage} />
            <View style={styles.itemInfo}>
              <Text style={styles.itemName}>{item.name}</Text>
              <Text style={styles.itemPrice}>${item.price.toFixed(2)}</Text>
            </View>
          </TouchableOpacity>
        ))}
      </ScrollView>

      <TouchableOpacity style={styles.ctaButton} onPress={sendEmail}>
        <Text style={styles.ctaText}>Contact Stagifique</Text>
      </TouchableOpacity>
    </View>
  )
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#fff",
  },
  header: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    padding: 10,
    backgroundColor: "#f8f8f8",
  },
  logo: {
    width: 120,
    height: 40,
    resizeMode: "contain",
  },
  content: {
    flex: 1,
    padding: 20,
  },
  categoryTitle: {
    fontSize: 24,
    fontWeight: "bold",
    marginBottom: 20,
  },
  itemContainer: {
    flexDirection: "row",
    marginBottom: 20,
    borderWidth: 1,
    borderColor: "#ddd",
    borderRadius: 10,
    overflow: "hidden",
  },
  itemImage: {
    width: 100,
    height: 100,
    resizeMode: "cover",
  },
  itemInfo: {
    flex: 1,
    padding: 10,
    justifyContent: "center",
  },
  itemName: {
    fontSize: 16,
    fontWeight: "bold",
    marginBottom: 5,
  },
  itemPrice: {
    fontSize: 14,
    color: "#007AFF",
  },
  ctaButton: {
    backgroundColor: "#007AFF",
    padding: 15,
    borderRadius: 5,
    margin: 20,
    alignItems: "center",
  },
  ctaText: {
    color: "white",
    fontSize: 18,
    fontWeight: "bold",
  },
})

export default CategoryPage

