"use client"

import { useState } from "react"
import { View, Text, FlatList, TouchableOpacity, StyleSheet, TextInput, Alert } from "react-native"
import { Ionicons } from "@expo/vector-icons"

// This would typically come from an API or database
const initialCollections = {
  "Living Room": [
    { id: "1", name: "Modern Minimalist", image: "/placeholder.svg?height=200&width=300" },
    { id: "2", name: "Rustic Charm", image: "/placeholder.svg?height=200&width=300" },
  ],
  Bedroom: [
    { id: "3", name: "Cozy Retreat", image: "/placeholder.svg?height=200&width=300" },
    { id: "4", name: "Luxe Glamour", image: "/placeholder.svg?height=200&width=300" },
  ],
}

const AdminPanel = () => {
  const [collections, setCollections] = useState(initialCollections)
  const [newItemName, setNewItemName] = useState("")
  const [selectedCategory, setSelectedCategory] = useState("Living Room")

  const addItem = () => {
    if (newItemName.trim() === "") {
      Alert.alert("Error", "Please enter a name for the new item")
      return
    }

    const newItem = {
      id: Date.now().toString(),
      name: newItemName,
      image: "/placeholder.svg?height=200&width=300",
    }

    setCollections((prevCollections) => ({
      ...prevCollections,
      [selectedCategory]: [...prevCollections[selectedCategory], newItem],
    }))

    setNewItemName("")
  }

  const deleteItem = (id) => {
    setCollections((prevCollections) => ({
      ...prevCollections,
      [selectedCategory]: prevCollections[selectedCategory].filter((item) => item.id !== id),
    }))
  }

  const renderItem = ({ item }) => (
    <View style={styles.item}>
      <Text>{item.name}</Text>
      <TouchableOpacity onPress={() => deleteItem(item.id)}>
        <Ionicons name="trash-outline" size={24} color="red" />
      </TouchableOpacity>
    </View>
  )

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Admin Panel</Text>
      <View style={styles.categorySelector}>
        {Object.keys(collections).map((category) => (
          <TouchableOpacity
            key={category}
            style={[styles.categoryButton, selectedCategory === category && styles.selectedCategory]}
            onPress={() => setSelectedCategory(category)}
          >
            <Text style={styles.categoryButtonText}>{category}</Text>
          </TouchableOpacity>
        ))}
      </View>
      <FlatList
        data={collections[selectedCategory]}
        renderItem={renderItem}
        keyExtractor={(item) => item.id}
        style={styles.list}
      />
      <View style={styles.addItemContainer}>
        <TextInput style={styles.input} value={newItemName} onChangeText={setNewItemName} placeholder="New item name" />
        <TouchableOpacity style={styles.addButton} onPress={addItem}>
          <Text style={styles.addButtonText}>Add Item</Text>
        </TouchableOpacity>
      </View>
    </View>
  )
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 20,
  },
  title: {
    fontSize: 24,
    fontWeight: "bold",
    marginBottom: 20,
  },
  categorySelector: {
    flexDirection: "row",
    justifyContent: "space-around",
    marginBottom: 20,
  },
  categoryButton: {
    padding: 10,
    borderRadius: 5,
    backgroundColor: "#f0f0f0",
  },
  selectedCategory: {
    backgroundColor: "#007AFF",
  },
  categoryButtonText: {
    fontWeight: "bold",
  },
  list: {
    flex: 1,
  },
  item: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    padding: 10,
    borderBottomWidth: 1,
    borderBottomColor: "#ccc",
  },
  addItemContainer: {
    flexDirection: "row",
    marginTop: 20,
  },
  input: {
    flex: 1,
    height: 40,
    borderColor: "gray",
    borderWidth: 1,
    borderRadius: 5,
    paddingHorizontal: 10,
    marginRight: 10,
  },
  addButton: {
    backgroundColor: "#007AFF",
    padding: 10,
    borderRadius: 5,
    justifyContent: "center",
    alignItems: "center",
  },
  addButtonText: {
    color: "white",
    fontWeight: "bold",
  },
})

export default AdminPanel

