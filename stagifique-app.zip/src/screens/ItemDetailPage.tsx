import { View, Text, StyleSheet, Image, ScrollView, TouchableOpacity, Linking } from "react-native"
import { useNavigation } from "@react-navigation/native"
import { Ionicons } from "@expo/vector-icons"

const ItemDetailPage = ({ route }) => {
  const { item } = route.params
  const navigation = useNavigation()

  const sendEmail = () => {
    Linking.openURL("mailto:info@stagifique.com")
  }

  return (
    <ScrollView style={styles.container}>
      <View style={styles.header}>
        <TouchableOpacity onPress={() => navigation.goBack()}>
          <Ionicons name="arrow-back" size={30} color="black" />
        </TouchableOpacity>
        <Image source={{ uri: "/placeholder.svg?height=40&width=120" }} style={styles.logo} />
        <View style={{ width: 30 }} />
      </View>

      <Image source={{ uri: item.image }} style={styles.itemImage} />

      <View style={styles.contentContainer}>
        <Text style={styles.itemName}>{item.name}</Text>
        <Text style={styles.itemBrand}>{item.brand}</Text>
        <Text style={styles.itemPrice}>${item.price.toFixed(2)}</Text>

        <Text style={styles.sectionTitle}>Description</Text>
        <Text style={styles.itemDescription}>{item.description}</Text>

        <Text style={styles.sectionTitle}>Details</Text>
        <View style={styles.detailsContainer}>
          <Text style={styles.detailItem}>Material: {item.material}</Text>
          <Text style={styles.detailItem}>Dimensions: {item.dimensions}</Text>
          <Text style={styles.detailItem}>Color: {item.color}</Text>
        </View>

        <TouchableOpacity style={styles.ctaButton} onPress={sendEmail}>
          <Text style={styles.ctaText}>Contact Stagifique about this item</Text>
        </TouchableOpacity>
      </View>
    </ScrollView>
  )
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#fff",
  },
  header: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    padding: 10,
    backgroundColor: "#f8f8f8",
  },
  logo: {
    width: 120,
    height: 40,
    resizeMode: "contain",
  },
  itemImage: {
    width: "100%",
    height: 300,
    resizeMode: "cover",
  },
  contentContainer: {
    padding: 20,
  },
  itemName: {
    fontSize: 24,
    fontWeight: "bold",
    marginBottom: 5,
  },
  itemBrand: {
    fontSize: 18,
    color: "#666",
    marginBottom: 10,
  },
  itemPrice: {
    fontSize: 22,
    fontWeight: "bold",
    color: "#007AFF",
    marginBottom: 20,
  },
  sectionTitle: {
    fontSize: 20,
    fontWeight: "bold",
    marginTop: 20,
    marginBottom: 10,
  },
  itemDescription: {
    fontSize: 16,
    lineHeight: 24,
    color: "#333",
  },
  detailsContainer: {
    marginTop: 10,
  },
  detailItem: {
    fontSize: 16,
    marginBottom: 5,
  },
  ctaButton: {
    backgroundColor: "#007AFF",
    padding: 15,
    borderRadius: 5,
    alignItems: "center",
    marginTop: 30,
  },
  ctaText: {
    color: "white",
    fontSize: 18,
    fontWeight: "bold",
  },
})

export default ItemDetailPage

