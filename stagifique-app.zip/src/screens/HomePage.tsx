"use client"

import { useState, useEffect } from "react"
import { View, Text, StyleSheet, Image, TouchableOpacity, Linking } from "react-native"
import SideMenu from "react-native-side-menu"
import Carousel from "react-native-snap-carousel"
import { Ionicons } from "@expo/vector-icons"
import { useNavigation } from "@react-navigation/native"
import { getFirestore, collection, getDocs } from "firebase/firestore"
import { app } from "../firebaseConfig" // You'll need to create this file

const HomePage = () => {
  const [isOpen, setIsOpen] = useState(false)
  const navigation = useNavigation()
  const [categories, setCategories] = useState([])
  const [carouselItems, setCarouselItems] = useState([])

  useEffect(() => {
    const fetchData = async () => {
      const db = getFirestore(app)
      const categoriesSnapshot = await getDocs(collection(db, "categories"))
      const categoriesData = categoriesSnapshot.docs.map((doc) => ({
        id: doc.id,
        ...doc.data(),
      }))
      setCategories(categoriesData)

      const carouselSnapshot = await getDocs(collection(db, "carousel"))
      const carouselData = carouselSnapshot.docs.map((doc) => doc.data())
      setCarouselItems(carouselData)
    }
    fetchData()
  }, [])

  const renderCarouselItem = ({ item }) => (
    <View style={styles.carouselItem}>
      <Image source={{ uri: item.image }} style={styles.carouselImage} />
      <Text style={styles.welcomeText}>{item.text}</Text>
    </View>
  )

  const menu = (
    <View style={styles.menu}>
      <Text style={styles.menuItem}>Home</Text>
      <Text style={styles.menuItem}>Categories</Text>
      <Text style={styles.menuItem}>About Us</Text>
      <TouchableOpacity onPress={() => navigation.navigate("Contact")}>
        <Text style={styles.menuItem}>Contact</Text>
      </TouchableOpacity>
    </View>
  )

  const sendEmail = () => {
    Linking.openURL("mailto:info@stagifique.com")
  }

  return (
    <SideMenu
      menu={menu}
      isOpen={isOpen}
      onChange={(isOpen) => setIsOpen(isOpen)}
      menuPosition="left"
      bounceBackOnOverdraw={false}
    >
      <View style={styles.container}>
        <View style={styles.header}>
          <TouchableOpacity onPress={() => setIsOpen(!isOpen)}>
            <Ionicons name="menu" size={30} color="black" />
          </TouchableOpacity>
          <Image source={{ uri: "/placeholder.svg?height=40&width=120" }} style={styles.logo} />
          <View style={{ width: 30 }} />
        </View>

        <Carousel
          data={carouselItems}
          renderItem={renderCarouselItem}
          sliderWidth={400}
          itemWidth={400}
          loop={true}
          autoplay={true}
        />

        <View style={styles.categoriesContainer}>
          {categories.map((category) => (
            <TouchableOpacity
              key={category.id}
              style={styles.categoryItem}
              onPress={() => navigation.navigate("Category", { category: category.name })}
            >
              <Image source={{ uri: category.image }} style={styles.categoryImage} />
              <Text style={styles.categoryText}>{category.name}</Text>
            </TouchableOpacity>
          ))}
        </View>

        <TouchableOpacity style={styles.ctaButton} onPress={sendEmail}>
          <Text style={styles.ctaText}>Contact Stagifique</Text>
        </TouchableOpacity>
        <TouchableOpacity style={styles.adminButton} onPress={() => navigation.navigate("AdminLogin")}>
          <Text style={styles.adminButtonText}>Admin Login</Text>
        </TouchableOpacity>
      </View>
    </SideMenu>
  )
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#fff",
  },
  header: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    padding: 10,
    backgroundColor: "#f8f8f8",
  },
  logo: {
    width: 120,
    height: 40,
    resizeMode: "contain",
  },
  carouselItem: {
    width: 400,
    height: 200,
    justifyContent: "center",
    alignItems: "center",
  },
  carouselImage: {
    width: "100%",
    height: "100%",
    resizeMode: "cover",
  },
  welcomeText: {
    position: "absolute",
    fontSize: 24,
    fontWeight: "bold",
    color: "white",
    textAlign: "center",
  },
  categoriesContainer: {
    flexDirection: "row",
    flexWrap: "wrap",
    justifyContent: "space-around",
    padding: 10,
  },
  categoryItem: {
    width: "45%",
    aspectRatio: 1,
    marginBottom: 20,
    alignItems: "center",
  },
  categoryImage: {
    width: "100%",
    height: "80%",
    resizeMode: "cover",
    borderRadius: 10,
  },
  categoryText: {
    marginTop: 5,
    fontSize: 16,
    fontWeight: "bold",
  },
  ctaButton: {
    backgroundColor: "#007AFF",
    padding: 15,
    borderRadius: 5,
    margin: 20,
    alignItems: "center",
  },
  ctaText: {
    color: "white",
    fontSize: 18,
    fontWeight: "bold",
  },
  menu: {
    flex: 1,
    backgroundColor: "#f8f8f8",
    padding: 20,
  },
  menuItem: {
    fontSize: 18,
    marginBottom: 20,
  },
  adminButton: {
    position: "absolute",
    top: 10,
    right: 10,
    backgroundColor: "#007AFF",
    padding: 10,
    borderRadius: 5,
  },
  adminButtonText: {
    color: "white",
    fontWeight: "bold",
  },
})

export default HomePage

