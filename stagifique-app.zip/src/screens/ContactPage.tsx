"use client"

import { useState } from "react"
import { View, Text, StyleSheet, Image, TouchableOpacity, ScrollView, TextInput, Alert, Linking } from "react-native"
import { useNavigation } from "@react-navigation/native"
import { Ionicons } from "@expo/vector-icons"

const ContactPage = () => {
  const navigation = useNavigation()
  const [name, setName] = useState("")
  const [email, setEmail] = useState("")
  const [message, setMessage] = useState("")

  const handleSubmit = () => {
    // In a real app, you would send this data to a server
    console.log({ name, email, message })
    Alert.alert("Thank you!", "Your message has been sent. We will get back to you soon.")
    setName("")
    setEmail("")
    setMessage("")
  }

  const openMap = () => {
    const address = "123 Furniture Lane, Design District, Cityville, 12345"
    const url = `https://maps.google.com/?q=${encodeURIComponent(address)}`
    Linking.openURL(url)
  }

  return (
    <ScrollView style={styles.container}>
      <View style={styles.header}>
        <TouchableOpacity onPress={() => navigation.goBack()}>
          <Ionicons name="arrow-back" size={30} color="black" />
        </TouchableOpacity>
        <Image source={{ uri: "/placeholder.svg?height=40&width=120" }} style={styles.logo} />
        <View style={{ width: 30 }} />
      </View>

      <View style={styles.content}>
        <Text style={styles.title}>Contact Stagifique</Text>

        <View style={styles.companyInfo}>
          <Text style={styles.infoTitle}>Visit Our Showroom</Text>
          <Text style={styles.infoText}>123 Furniture Lane, Design District</Text>
          <Text style={styles.infoText}>Cityville, 12345</Text>
          <TouchableOpacity onPress={openMap}>
            <Text style={styles.linkText}>Open in Maps</Text>
          </TouchableOpacity>

          <Text style={styles.infoTitle}>Contact Information</Text>
          <Text style={styles.infoText}>Phone: (555) 123-4567</Text>
          <Text style={styles.infoText}>Email: info@stagifique.com</Text>

          <Text style={styles.infoTitle}>Business Hours</Text>
          <Text style={styles.infoText}>Monday - Friday: 9:00 AM - 6:00 PM</Text>
          <Text style={styles.infoText}>Saturday: 10:00 AM - 4:00 PM</Text>
          <Text style={styles.infoText}>Sunday: Closed</Text>
        </View>

        <View style={styles.formContainer}>
          <Text style={styles.formTitle}>Send Us a Message</Text>
          <TextInput style={styles.input} placeholder="Your Name" value={name} onChangeText={setName} />
          <TextInput
            style={styles.input}
            placeholder="Your Email"
            value={email}
            onChangeText={setEmail}
            keyboardType="email-address"
          />
          <TextInput
            style={[styles.input, styles.messageInput]}
            placeholder="Your Message"
            value={message}
            onChangeText={setMessage}
            multiline
          />
          <TouchableOpacity style={styles.submitButton} onPress={handleSubmit}>
            <Text style={styles.submitButtonText}>Send Message</Text>
          </TouchableOpacity>
        </View>
      </View>
    </ScrollView>
  )
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#fff",
  },
  header: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    padding: 10,
    backgroundColor: "#f8f8f8",
  },
  logo: {
    width: 120,
    height: 40,
    resizeMode: "contain",
  },
  content: {
    padding: 20,
  },
  title: {
    fontSize: 24,
    fontWeight: "bold",
    marginBottom: 20,
  },
  companyInfo: {
    marginBottom: 30,
  },
  infoTitle: {
    fontSize: 18,
    fontWeight: "bold",
    marginTop: 15,
    marginBottom: 5,
  },
  infoText: {
    fontSize: 16,
    marginBottom: 3,
  },
  linkText: {
    color: "#007AFF",
    fontSize: 16,
    marginTop: 5,
  },
  formContainer: {
    backgroundColor: "#f8f8f8",
    padding: 20,
    borderRadius: 10,
  },
  formTitle: {
    fontSize: 20,
    fontWeight: "bold",
    marginBottom: 15,
  },
  input: {
    backgroundColor: "#fff",
    padding: 10,
    borderRadius: 5,
    marginBottom: 10,
    fontSize: 16,
  },
  messageInput: {
    height: 100,
    textAlignVertical: "top",
  },
  submitButton: {
    backgroundColor: "#007AFF",
    padding: 15,
    borderRadius: 5,
    alignItems: "center",
  },
  submitButtonText: {
    color: "white",
    fontSize: 18,
    fontWeight: "bold",
  },
})

export default ContactPage

