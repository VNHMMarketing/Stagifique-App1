import { initializeApp } from "firebase/app"
// Your web app's Firebase configuration
// For Firebase JS SDK v7.20.0 and later, measurementId is optional
const firebaseConfig = {
  // Add your Firebase configuration here
}

// Initialize Firebase
export const app = initializeApp(firebaseConfig)

